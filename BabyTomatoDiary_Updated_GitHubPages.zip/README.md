# Baby Tomato Diary

GitHub Pages-ready version. The main site file is `index.html` at the repository root.

The interface is slightly zoomed out to show more of the page at once. The writing editor includes per-chapter ink colours (classic, baby pink, red, cyan, yellow, orange, purple, blue, and green). Existing diary projects remain compatible with the updated version.
